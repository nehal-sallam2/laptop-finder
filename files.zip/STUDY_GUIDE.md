# Study guide: Student Laptop Finder

## Run it
    npm install
    npm run build
    VS Code -> Go Live -> index.html
Rename the folder to laptop_finder_<yourname> and add your GitHub link to README.md.

## Requirement checklist (all done and tested in Chromium at 375, 768, 1280 px)
- 25 laptops in data/laptops.json with all 13 fields: done
- fetch + async/await + try/catch, skeleton while loading, readable error message: api.js + every page file
- 3+ ES modules, 5+ reusable functions, 2+ arrow functions, card reused on home, catalogue, favorites: done
- map (cards, rows), filter (search/filters), sort on a copy, reduce (stats, totals, best value): done
- Search (name/brand, live), category, max price, min RAM, min battery, sort price/battery/weight both ways, count, no-result message: done
- details.html uses URLSearchParams; missing or unknown id gives a friendly message: done
- Favorites: add/remove from cards and details, saved state on buttons, clear all, total and average, survives reload: done
- Compare: 2 to 4, fifth blocked with message, same rows, best values from JavaScript: done
- Tailwind: local npm install, @import "tailwindcss", @theme, @plugin (forms + typography), @layer components with @apply (.laptop-card, .btn-action, .btn-outline, .field, .check, .nav-link), animate-pulse skeletons, hover/focus transitions, sm/md/lg breakpoints, mobile menu toggle, compare table scrolls inside wrapper: done
- No inline styles, CDN, libraries or templates: verified by search
- Three user journeys: tested end to end; theme and favorites identical on all five pages

## Key JavaScript to explain
- fetchLaptops (api.js): fetch the JSON, check response.ok, throw a friendly Error in catch.
- readJSON / writeJSON (storage.js): JSON.parse / JSON.stringify around localStorage, with a fallback.
- toggleFavorite: add if missing, remove if present, returns the new state. Removing also drops it from the comparison.
- getCompareIds: saved selection filtered to current favorites; first four favorites if nothing chosen yet.
- createLaptopCard (ui.js): returns a template-literal string; the same function renders cards on 3 pages.
- enableFavoriteButtons: event delegation, one click listener on the container handles all buttons, even after re-render.
- filterLaptops (catalogue.js): one filter() whose callback requires every condition, so filters combine.
- sortLaptops: copies with [...laptops] then sort(a - b) or sort(b - a) for ascending/descending.
- calculateStats / favorites totals: reduce() accumulates sum or lowest value.
- getBestValue (compare.js): reduce() keeps the best value so far; "min" for price/weight, "max" for RAM/storage/battery; null if all equal.
- applyTheme + theme-init.js: sets data-theme on <html>; the head script restores it before paint (no flash).
- URLSearchParams in details.js: Number(params.get("id")) then findLaptopById.

## Key Tailwind to explain
- @import "tailwindcss": loads Tailwind 4.
- @theme: defines colour variables for both themes (Performance and Saver) and the active tokens (page, panel, ink, accent...). html[data-theme="battery"] swaps the active tokens, so every utility like bg-page changes at once.
- @plugin: forms styles inputs, selects and checkboxes (select arrow, checkbox tick); typography (prose) styles the description text.
- @layer components + @apply: build reusable classes from utilities.
- animate-pulse: skeleton cards that match the card shape.
- Responsive: grid sm:grid-cols-2 lg:grid-cols-3; hidden md:flex for desktop nav; the Menu button toggles the hidden class.

## Likely instructor questions
- Why a copy before sort()? sort() mutates the original array and would break the default order and the other filters.
- Why event delegation? Cards are re-created on every filter change, so listeners on each button would be lost.
- Why must fetch use a server? Browsers block file:// requests for security.
- Why is theme-init.js not a module? Modules are deferred and run after paint, which would flash the wrong theme.
